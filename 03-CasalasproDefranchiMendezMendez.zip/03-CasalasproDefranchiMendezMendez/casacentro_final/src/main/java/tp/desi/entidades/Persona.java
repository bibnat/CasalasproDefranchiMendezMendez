package tp.desi.entidades;

import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.Column;
import java.time.LocalDate;

@MappedSuperclass
public abstract class Persona {

    @Column(nullable = false, unique = true)
    private int dni;

    private String nombre;
    private String apellido;
    private LocalDate fechaNacimiento;
    private String ocupacion;

    // Getters y Setters
    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getOcupacion() {
        return ocupacion;
    }

    public void setOcupacion(String ocupacion) {
        this.ocupacion = ocupacion;
    }
}
